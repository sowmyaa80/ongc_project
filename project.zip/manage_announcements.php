<?php
require_once 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] === 'user') { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'publish') {
        $msg = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'Info';
        if (!empty($msg)) {
            $pdo->prepare("INSERT INTO announcements (message, type, status) VALUES (?, ?, 'Active')")->execute([$msg, $type]);
        }
    } elseif ($_POST['action'] === 'toggle') {
        $id = $_POST['id'] ?? 0;
        $current = $_POST['current_status'] ?? 'Active';
        $next = ($current === 'Active') ? 'Hidden' : 'Active';
        $pdo->prepare("UPDATE announcements SET status = ? WHERE id = ?")->execute([$next, $id]);
    } elseif ($_POST['action'] === 'delete') {
        $id = $_POST['id'] ?? 0;
        $pdo->prepare("DELETE FROM announcements WHERE id = ?")->execute([$id]);
    }
    header('Location: manage_announcements.php'); exit;
}

$announcements = $pdo->query("SELECT * FROM announcements ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Announcement Control</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: #f3f4f6; color: #334155; }
        .header-strip { background: white; padding: 20px 30px; display: flex; justify-content: space-between; border-bottom: 1px solid #e5e7eb; align-items: center;}
        .container { display: grid; grid-template-columns: 1fr 2fr; gap: 30px; padding: 30px; }
        .card { background: white; border-radius: 8px; border: 1px solid #e5e7eb; overflow: hidden; }
        .card-header { padding: 15px 20px; background: #0077b6; color: white; font-weight: 600; }
        .card-body { padding: 20px; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; margin-top:6px; }
        .btn { padding: 12px 20px; border-radius: 6px; font-weight: 700; cursor: pointer; border: none; font-size: 14px; }
        .btn-green { background: #0f9d58; color: white; width: 100%; margin-top: 15px; }
        .btn-back { background:#64748b; color:white; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:600; }
        .data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .data-table th { background: #262c36; color: white; padding: 12px 20px; font-weight: 600; text-align: left; }
        .data-table td { padding: 16px 20px; border-bottom: 1px solid #e5e7eb; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; color:white; }
        .bg-active { background:#0f9d58; } .bg-hidden { background:#64748b; }
        .bg-warn { background:#ffb703; color:#023047; }
        .action-flex { display: flex; gap: 5px; }
        .btn-action { padding: 4px 8px; border: 1px solid #cbd5e1; background: white; cursor: pointer; border-radius:4px;}
    </style>
</head>
<body>

    <div class="header-strip">
        <h2><i class="fa-solid fa-bullhorn" style="color:#0077b6;"></i> Announcement Control</h2>
        <a href="index.php" class="btn-back">← Back to Home</a>
    </div>

    <div class="container">
        <div class="card">
            <div class="card-header" style="background:#1a73e8;">Post New Message</div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="publish">
                    <div style="margin-bottom:15px;">
                        <label>Message Text</label>
                        <textarea name="message" class="form-control" style="height:100px;" placeholder="e.g. Server restarting in 5 mins..." required></textarea>
                    </div>
                    <div>
                        <label>Type (Color)</label>
                        <select name="type" class="form-control">
                            <option value="Info">Info (Blue)</option>
                            <option value="Warning">Warning (Yellow)</option>
                            <option value="Critical">Critical (Red)</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-green">Post Announcement</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header" style="background:#262c36;">Current Announcements</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Message</th>
                        <th>Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($announcements as $a): ?>
                    <tr>
                        <td><span class="badge <?= $a['status'] === 'Active' ? 'bg-active' : 'bg-hidden' ?>"><?= $a['status'] ?></span></td>
                        <td style="font-weight:500;"><?= htmlspecialchars($a['message']) ?></td>
                        <td><span class="badge bg-warn"><?= $a['type'] ?></span></td>
                        <td>
                            <div class="action-flex">
                                <form method="POST">
                                    <input type="hidden" name="action" value="toggle">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <input type="hidden" name="current_status" value="<?= $a['status'] ?>">
                                    <button type="submit" class="btn-action"><?= $a['status'] === 'Active' ? 'Hide' : 'Show' ?></button>
                                </form>
                                <form method="POST">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                                    <button type="submit" class="btn-action" style="color:red;">X</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>