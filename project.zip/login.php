<?php
require_once 'db.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        // Standard or hashed password check matching your database state
        if ($user && ($password === $user['password'] || password_verify($password, $user['password']))) {
            $_SESSION['user_id'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit;
        } else {
            $error = 'Invalid Username or Password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>G&G Support Portal - Login</title>
    <style>
        body { background-color: #22447e; font-family: 'Segoe UI', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin:0; }
        .login-card { background: white; width: 380px; border-radius: 14px; box-shadow: 0 10px 25px rgba(0,0,0,0.2); padding: 40px 30px; text-align: center; }
        .logo-img-placeholder { width: 85px; height: 85px; background: #edf2f7; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; border: 2px solid #e2e8f0; font-size: 11px; font-weight: bold; color: #22447e; text-align: center; line-height: 1.2; }
        h2 { font-size: 24px; color: #1e293b; margin: 10px 0 4px; font-weight: 700; }
        .subtitle { font-size: 13px; color: #64748b; margin-bottom: 25px; }
        .form-group { text-align: left; margin-bottom: 18px; }
        label { display: block; font-size: 12px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control { width: 100%; padding: 12px; background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; box-sizing: border-box; }
        .btn-submit { width: 100%; background: #22447e; color: white; padding: 14px; font-size: 14px; font-weight: 700; border: none; border-radius: 6px; cursor: pointer; text-transform: uppercase; margin-top: 10px; }
        .err-container { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 6px; font-size: 13px; margin-bottom: 15px; text-align: left; }
        .footer-text { margin-top: 35px; font-size: 11px; color: #94a3b8; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo-img-placeholder">INTEGRATED G&G<br>SOLUTIONS HUB</div>
        <h2>G&G Support Portal</h2>
        <div class="subtitle">Authorized Access Only</div>

        <?php if($error): ?>
            <div class="err-container">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="141486" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn-submit">Secure Sign In</button>
        </form>
        <div class="footer-text">© 2026 Developed and Maintained by Database Group, KG-PG Basin</div>
    </div>
</body>
</html>