<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$host = '127.0.0.1:3307'; // <-- Forces the connection over your exact custom port
$db   = 'ongc_support_db'; 
$user = 'root';
$pass = '';               // <-- Kept completely empty as verified by phpMyAdmin
$charset = 'utf8mb4';
try {
     $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass, [
         PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES   => false,
     ]);
} catch (\PDOException $e) {
     die("Database connection failed: " . $e->getMessage());
}
?>