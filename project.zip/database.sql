-- ====================================================================
-- G&G SUPPORT PORTAL - DATABASE SCHEMA & INITIALIZATION DATA
-- Target Engine: MySQL / MariaDB (XAMPP phpMyAdmin compatible)
-- Database Name: ongc_support_db
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `ongc_support_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ongc_support_db`;

-- --------------------------------------------------------------------
-- 1. TABLE STRUCTURE FOR: USERS
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `designation` VARCHAR(100) NOT NULL,
  `role` ENUM('user', 'admin', 'super_admin') NOT NULL DEFAULT 'user',
  `password` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- 2. TABLE STRUCTURE FOR: CATEGORIES (Hierarchical Matrix Structure)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `main_category` VARCHAR(100) NOT NULL,
  `subcategory` VARCHAR(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- 3. TABLE STRUCTURE FOR: ANNOUNCEMENTS (Horizontal Scrolling Tickers)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `message` TEXT NOT NULL,
  `type` ENUM('Info', 'Warning', 'Critical') NOT NULL DEFAULT 'Info',
  `status` ENUM('Active', 'Hidden') NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- 4. TABLE STRUCTURE FOR: SOLUTIONS (Knowledge Base Repository Logs)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `solutions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category` VARCHAR(100) NOT NULL,
  `subcategory` VARCHAR(100) DEFAULT '',
  `title` VARCHAR(255) NOT NULL,
  `short_summary` TEXT,
  `author` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ====================================================================
-- INITIAL DATABASE VALUES & DATA SEEDING
-- ====================================================================

-- Seed primary administrative profile (Username: 141486 | Password: 123)
INSERT IGNORE INTO `users` (`id`, `username`, `designation`, `role`, `password`) VALUES 
(1, '141486', 'G&G Infrastructure Admin', 'super_admin', '123');

-- Seed classification rules for standard system dropdown arrays
INSERT INTO `categories` (`id`, `main_category`, `subcategory`) VALUES 
(1, 'Application', 'Browser'),
(2, 'Application', 'DSG'),
(3, 'Application', 'MS Office'),
(4, 'Application', 'Oracle Client'),
(5, 'Application', 'Outlook'),
(6, 'User Support', 'Account Lockout');

-- Seed current notification ticker parameters
INSERT INTO `announcements` (`id`, `message`, `type`, `status`) VALUES 
(1, 'Today is holiday', 'Info', 'Active'),
(2, 'System Maintenance scheduled for Saturday 10 PM. Please save your work.', 'Warning', 'Active');

-- Seed preliminary core log rows to clear base validation array views
INSERT INTO `solutions` (`id`, `category`, `subcategory`, `title`, `short_summary`, `author`) VALUES 
(21, 'Application', 'Oracle Client', 'Oracle client installation issue in the windows', 'A peculiar error while trying to install Oracle client on windows workstation instances.', '141486'),
(22, 'User Support', 'Account Lockout', 'User account locked out', 'User unable to login due to account locked out after multiple attempts.', '141486');

COMMIT;