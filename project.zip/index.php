<?php
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

$tickers = $pdo->query("SELECT * FROM announcements WHERE status = 'Active'")->fetchAll();
$solutions = $pdo->query("SELECT * FROM solutions ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>G&G Support Portal - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: #f3f4f6; color: #334155; min-height: 100vh; display: flex; flex-direction: column; }
        .top-navbar { background-color: #22447e; color: white; padding: 12px 25px; display: flex; justify-content: space-between; align-items: center; }
        .brand { display: flex; align-items: center; gap: 10px; font-size: 20px; font-weight: 700; }
        .user-meta { display: flex; align-items: center; gap: 15px; font-size: 14px; }
        .role-badge { background-color: #ffb703; color: #023047; padding: 3px 10px; border-radius: 4px; font-weight: bold; font-size: 12px; }
        .btn-menu { background: #ffb703; color: #023047; font-weight: 700; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }
        .btn-logout { background: transparent; border: 1px solid white; color: white; padding: 6px 14px; border-radius: 4px; cursor: pointer; text-decoration:none; font-size:13px; }
        
        .ticker-section { background-color: white; border-bottom: 1px solid #e5e7eb; padding: 10px 25px; display: flex; gap: 30px; font-size: 14px; font-weight: 600; overflow-x: auto; }
        .ticker-item { display: flex; align-items: center; gap: 6px; }
        
        .workspace { padding: 25px; flex: 1; }
        .filters-panel { background: white; border-radius: 8px; padding: 20px; margin-bottom: 25px; border: 1px solid #e5e7eb; display: grid; grid-template-columns: repeat(4, 1fr) auto; gap: 15px; align-items: end; }
        .filter-group label { display: block; font-size: 11px; font-weight: 700; color: #94a3b8; margin-bottom: 6px; text-transform: uppercase; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; background:#f8fafc; }
        .btn-reset { padding: 10px 20px; background: white; border: 1px solid #cbd5e1; border-radius: 6px; cursor: pointer; font-weight: 600; }
        
        .card { background: white; border-radius: 8px; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .card-header { padding: 15px 20px; border-bottom: 1px solid #e5e7eb; font-weight: 700; font-size: 16px; display: flex; align-items: center; gap: 8px; }
        .data-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
        .data-table th { background: #f8fafc; padding: 12px 20px; font-weight: 600; color: #64748b; border-bottom: 2px solid #e5e7eb; text-transform: uppercase; font-size: 12px; }
        .data-table td { padding: 16px 20px; border-bottom: 1px solid #e5e7eb; vertical-align: middle; }
        
        .badge-cat { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
        .cat-user { background: #fef3c7; color: #d97706; border: 1px solid #fde68a; }
        .cat-app { background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; }
        .btn-open { background: #0077b6; color: white; padding: 6px 16px; border: none; border-radius: 20px; cursor: pointer; text-decoration: none; font-weight:600; font-size:13px; }
        
        .admin-dropdown { position: relative; display: inline-block; }
        .dropdown-content { display: none; position: absolute; right: 0; background-color: white; min-width: 220px; box-shadow: 0px 8px 16px rgba(0,0,0,0.1); z-index: 5; border-radius: 6px; margin-top: 5px; border: 1px solid #cbd5e1; }
        .dropdown-content a { color: #334155; padding: 12px 16px; text-decoration: none; display: block; font-size: 14px; }
        .dropdown-content a:hover { background-color: #f1f5f9; color: #22447e; }
        .admin-dropdown:hover .dropdown-content { display: block; }
        
        footer { background: #e2e8f0; text-align: center; padding: 15px; font-size: 13px; color: #475569; border-top: 1px solid #cbd5e1; margin-top: auto; }
    </style>
</head>
<body>

    <header class="top-navbar">
        <div class="brand"><i class="fa-solid fa-square-poll-horizontal"></i> G&G Support Portal</div>
        <div class="user-meta">
            <span>CURRENT USER: <strong><?= htmlspecialchars($_SESSION['user_id']) ?></strong></span>
            <span class="role-badge"><?= strtoupper(htmlspecialchars($_SESSION['role'])) ?></span>
            
            <div class="admin-dropdown">
                <button class="btn-menu"><i class="fa-solid fa-rocket"></i> Menu <i class="fa-solid fa-chevron-down" style="font-size:10px;"></i></button>
                <div class="dropdown-content">
                    <a href="publish_solution.php"><i class="fa-solid fa-plus-circle"></i> Create Solution Article</a>
                    <?php if($_SESSION['role'] !== 'user'): ?>
                        <a href="manage_categories.php"><i class="fa-solid fa-tags"></i> Category Management</a>
                        <a href="manage_announcements.php"><i class="fa-solid fa-bullhorn"></i> Announcement Control</a>
                    <?php endif; ?>
                </div>
            </div>
            <a href="login.php" class="btn-logout">Logout</a>
        </div>
    </header>

    <section class="ticker-section">
        <?php foreach($tickers as $t): ?>
            <div class="ticker-item" style="color: <?= $t['type'] === 'Critical' ? '#dc2626' : ($t['type'] === 'Warning' ? '#d97706' : '#0f9d58') ?>;">
                <i class="fa-solid fa-circle-exclamation"></i> 
                <span><?= htmlspecialchars($t['message']) ?></span>
            </div>
        <?php endforeach; if(count($tickers) == 0) echo "<span style='color:#0f9d58;'><i class='fa-solid fa-circle-check'></i> All systems functional. No active notifications.</span>"; ?>
    </section>

    <main class="workspace">
        <section class="filters-panel">
            <div class="filter-group">
                <label>Filter Category</label>
                <select class="form-control"><option>All Categories</option></select>
            </div>
            <div class="filter-group">
                <label>Subcategory</label>
                <select class="form-control"><option>All Subcategories</option></select>
            </div>
            <div class="filter-group">
                <label>Author</label>
                <select class="form-control"><option>All Authors</option></select>
            </div>
            <div class="filter-group">
                <label>Date Added</label>
                <input type="date" class="form-control">
            </div>
            <button class="btn-reset">Reset</button>
        </section>

        <div class="card">
            <div class="card-header"><i class="fa-solid fa-book-bookmark" style="color:#0f9d58;"></i> Solution Repository</div>
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category System</th>
                            <th>Issue Title</th>
                            <th>Preview</th>
                            <th>Author</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($solutions as $s): ?>
                        <tr>
                            <td>#<?= $s['id'] ?></td>
                            <td>
                                <span class="badge-cat <?= strtolower($s['category']) === 'application' ? 'cat-app' : 'cat-user' ?>">
                                    <?= htmlspecialchars($s['category']) ?>
                                </span>
                                <div style="font-size:11px; color:#64748b; margin-top:3px; padding-left:4px;">↳ <?= htmlspecialchars($s['subcategory']) ?></div>
                            </td>
                            <td><strong><?= htmlspecialchars($s['title']) ?></strong> <span style="color:red; font-size:11px; font-style:italic;">🔒 Internal Only</span></td>
                            <td style="color:#475569; max-width: 350px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?= htmlspecialchars($s['short_summary']) ?></td>
                            <td><i class="fa-regular fa-user" style="color:#94a3b8;"></i> <?= htmlspecialchars($s['author']) ?></td>
                            <td><a href="#" class="btn-open" onclick="alert('Details: <?= addslashes($s['short_summary']) ?>')">Open</a></td>
                        </tr>
                        <?php endforeach; if(count($solutions) == 0): ?>
                            <tr><td colspan="6" style="text-align:center; color:#94a3b8; padding:40px;">No recorded configurations.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer>Developed and Maintained by <strong style="color:#22447e;">Database Group</strong>, KG-PG Basin</footer>
</body>
</html>