<?php
// 1. Corrected file path to target your database file directly
include("db.php"); 

if(isset($_POST['register'])){

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    // 2. Fix for Enum schema: converts 'superadmin' from HTML to 'super_admin' for MySQL
    if ($role === 'superadmin') {
        $role = 'super_admin';
    }

    // Check if the username/email already exists
    $check_stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $check_stmt->execute([$email]);
    
    if($check_stmt->rowCount() > 0){
        echo "<script>alert('Username/Email Already Exists');</script>";
    } else {
        // Maps form data safely into your active database schema
        $sql = "INSERT INTO users (username, designation, password, role) VALUES (?, ?, ?, ?)";
        $insert_stmt = $pdo->prepare($sql);
        $insert_stmt->execute([$email, $name, $password, $role]);

        echo "<script>
        alert('Registration Successful');
        window.location='login.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - G&G Portal</title>
    <style>
        body {
            background: #0f172a;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
        }
        .signup-box {
            width: 400px;
            background: #1e293b;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 10px 25px rgba(0,0,0,0.5);
        }
        .signup-box h1 {
            text-align: center;
            color: #38bdf8;
            margin-top: 0;
            font-size: 28px;
        }
        input, select {
            width: 100%;
            padding: 12px;
            margin-top: 15px;
            background: #0f172a;
            border: 1px solid #334155;
            color: white;
            border-radius: 8px;
            box-sizing: border-box;
        }
        button {
            width: 100%;
            padding: 12px;
            margin-top: 24px;
            background: #38bdf8;
            border: none;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background: #0ea5e9;
        }
        p {
            text-align: center;
            margin-top: 20px;
            color: #94a3b8;
            font-size: 14px;
        }
        a {
            color: #38bdf8;
            text-decoration: none;
            font-weight: 600;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="signup-box">
    <h1>Create Account</h1>
    <form method="POST">
        <input type="text" name="name" placeholder="Enter Name" required>
        <input type="email" name="email" placeholder="Enter Email" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <select name="role">
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="superadmin">Super Admin</option>
        </select>
        <button name="register" type="submit">Sign Up</button>
    </form>
    <p>Already have an account? <a href="login.php">Login</a></p>
</div>

</body>
</html>