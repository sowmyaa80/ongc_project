<?php
require_once 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] === 'user') { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_main') {
        $name = trim($_POST['main_name'] ?? '');
        if (!empty($name)) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO categories (main_category, subcategory) VALUES (?, '')");
            $stmt->execute([$name]);
        }
    } elseif ($_POST['action'] === 'add_sub') {
        $parent = $_POST['parent_name'] ?? '';
        $sub = trim($_POST['sub_name'] ?? '');
        if (!empty($parent) && !empty($sub)) {
            $stmt = $pdo->prepare("INSERT INTO categories (main_category, subcategory) VALUES (?, ?)");
            $stmt->execute([$parent, $sub]);
        }
    } elseif ($_POST['action'] === 'delete') {
        $id = $_POST['id'] ?? 0;
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
    }
    header('Location: manage_categories.php'); exit;
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY main_category, subcategory")->fetchAll();
$mainCategories = $pdo->query("SELECT DISTINCT main_category FROM categories WHERE main_category != ''")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Category Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: #f3f4f6; color: #334155; }
        .header-strip { background: white; padding: 20px 30px; display: flex; justify-content: space-between; border-bottom: 1px solid #e5e7eb; align-items: center;}
        .container { display: grid; grid-template-columns: 1fr 2fr; gap: 30px; padding: 30px; }
        .card { background: white; border-radius: 8px; border: 1px solid #e5e7eb; overflow: hidden; margin-bottom:20px; }
        .card-header { padding: 15px 20px; background: #262c36; color: white; font-weight: 600; display: flex; align-items: center; gap: 8px; }
        .card-body { padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-size: 13px; font-weight: 600; color: #475569; margin-bottom: 6px; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; }
        .btn { padding: 10px 18px; border-radius: 6px; font-weight: 700; cursor: pointer; border: none; font-size: 14px; }
        .btn-blue { background: #0077b6; color: white; }
        .btn-green { background: #0f9d58; color: white; width: 100%; }
        .btn-back { background:#64748b; color:white; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:600; }
        .data-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .data-table th { background: #262c36; color: white; padding: 12px 20px; font-weight: 600; text-align: left; }
        .data-table td { padding: 12px 20px; border-bottom: 1px solid #e5e7eb; }
        .btn-delete { background: none; border: 1px solid #fca5a5; color: #dc2626; padding: 4px 12px; border-radius: 4px; cursor: pointer; font-weight:600; }
    </style>
</head>
<body>

    <div class="header-strip">
        <h2><i class="fa-solid fa-folder-open" style="color:#22447e;"></i> Category Management</h2>
        <a href="index.php" class="btn-back">← Back to Home</a>
    </div>

    <div class="container">
        <div>
            <div class="card">
                <div class="card-header"><i class="fa-solid fa-square-plus"></i> Manage Actions</div>
                <div class="card-body">
                    <form method="POST" style="margin-bottom: 25px;">
                        <input type="hidden" name="action" value="add_main">
                        <label style="color:#0077b6;">1. Add Main Category</label>
                        <div style="display:flex; gap:10px; margin-top:6px;">
                            <input type="text" name="main_name" class="form-control" placeholder="e.g. Storage" required>
                            <button type="submit" class="btn btn-blue">Add</button>
                        </div>
                    </form>
                    
                    <hr style="border:0; border-top:1px solid #e5e7eb; margin:20px 0;">

                    <form method="POST">
                        <input type="hidden" name="action" value="add_sub">
                        <label style="color:#0f9d58;">2. Add Subcategory</label>
                        <div class="form-group" style="margin-top:10px;">
                            <select name="parent_name" class="form-control" required>
                                <option value="">Choose Parent...</option>
                                <?php foreach($mainCategories as $mc): ?>
                                    <option value="<?= htmlspecialchars($mc['main_category']) ?>"><?= htmlspecialchars($mc['main_category']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="text" name="sub_name" class="form-control" placeholder="e.g. NAS / SAN" required>
                        </div>
                        <button type="submit" class="btn btn-green">Create Subcategory</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">Current Structure</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Parent Category</th>
                        <th>Subcategory</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($categories as $c): if(empty($c['subcategory'])) continue; ?>
                    <tr>
                        <td style="color:#0077b6; font-weight:700;"><?= htmlspecialchars($c['main_category']) ?></td>
                        <td><?= htmlspecialchars($c['subcategory']) ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>