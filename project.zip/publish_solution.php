<?php
require_once 'db.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $title = trim($_POST['title'] ?? '');
     $cat = $_POST['category'] ?? '';
     $sub = $_POST['subcategory'] ?? '';
     $summary = trim($_POST['summary'] ?? '');
     
     if(!empty($title) && !empty($cat)) {
          $stmt = $pdo->prepare("INSERT INTO solutions (category, subcategory, title, short_summary, author) VALUES (?, ?, ?, ?, ?)");
          $stmt->execute([$cat, $sub, $title, $summary, $_SESSION['user_id']]);
          header('Location: index.php'); exit;
     }
}

$categories = $pdo->query("SELECT DISTINCT main_category FROM categories WHERE main_category != ''")->fetchAll();
$subCategories = $pdo->query("SELECT DISTINCT subcategory FROM categories WHERE subcategory != ''")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Knowledge Base - New Entry</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; }
        body { background-color: #f3f4f6; padding: 40px; display:flex; flex-direction:column; align-items:center; }
        .wrapper { width: 100%; max-width: 800px; }
        .top-nav-box { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; width:100%; }
        .card { background: white; border-radius: 8px; border: 1px solid #cbd5e1; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .card-header { background: #3b60a0; color: white; padding: 15px 20px; font-weight: 700; font-size:16px; }
        .card-body { padding: 30px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-size: 11px; font-weight: 800; color: #1e3a8a; text-transform: uppercase; margin-bottom: 6px; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 15px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .editor-toolbar { background: #f1f5f9; border: 1px solid #cbd5e1; border-bottom: none; padding: 8px; display: flex; gap: 5px; border-top-left-radius: 6px; border-top-right-radius: 6px; }
        .editor-area { width: 100%; height: 180px; border: 1px solid #cbd5e1; padding: 15px; border-bottom-left-radius: 6px; border-bottom-right-radius: 6px; resize: none; }
        .btn-publish { background: #0f9d58; color: white; width: 100%; padding: 15px; border: none; border-radius: 6px; font-weight: 700; font-size: 16px; cursor: pointer; margin-top: 10px; }
        .btn-back { padding: 6px 16px; background: white; border: 1px solid #cbd5e1; border-radius: 20px; text-decoration: none; color: #475569; font-size: 13px; font-weight: 600; }
    </style>
</head>
<body>

    <div class="wrapper">
        <div class="top-nav-box">
            <div>
                <h1 style="font-size:24px; color:#1e293b;">Knowledge Base</h1>
                <p style="font-size:12px; color:#64748b;">Create a new technical solution article</p>
            </div>
            <a href="index.php" class="btn-back">← Back to Dashboard</a>
        </div>

        <div class="card">
            <div class="card-header"><i class="fa-solid fa-file-lines"></i> New Solution Entry</div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label>Issue Title</label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Printer Jam in HR Department" required>
                    </div>
                    
                    <div class="grid-2 form-group">
                        <div>
                            <label>Category</label>
                            <select name="category" class="form-control" required>
                                <option value="">Select Main Category...</option>
                                <?php foreach($categories as $c): ?>
                                    <option value="<?= htmlspecialchars($c['main_category']) ?>"><?= htmlspecialchars($c['main_category']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Subcategory</label>
                            <select name="subcategory" class="form-control">
                                <option value="">Select Subcategory...</option>
                                <?php foreach($subCategories as $sc): ?>
                                    <option value="<?= htmlspecialchars($sc['subcategory']) ?>"><?= htmlspecialchars($sc['subcategory']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Short Summary (Plain Text)</label>
                        <input type="text" name="summary" class="form-control" placeholder="Brief 1-2 sentence summary...">
                    </div>

                    <div class="form-group">
                        <label>Detailed Solution Steps</label>
                        <div class="editor-toolbar">
                            <button type="button" style="padding:2px 6px;"><b>B</b></button>
                            <button type="button" style="padding:2px 6px;"><i>I</i></button>
                            <button type="button" style="padding:2px 6px;"><u>U</u></button>
                        </div>
                        <textarea class="editor-area" placeholder="Type your detailed solution steps here..."></textarea>
                    </div>

                    <button type="submit" class="btn-publish"><i class="fa-solid fa-circle-check"></i> Publish Solution</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>